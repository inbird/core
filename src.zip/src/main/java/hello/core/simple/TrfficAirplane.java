package hello.core.simple;

public class TrfficAirplane implements Traffic{
    @Override
    public void go() {
        System.out.println("Fly : Airplane");
    }
}
