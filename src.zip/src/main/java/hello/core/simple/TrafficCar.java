package hello.core.simple;

public class TrafficCar implements Traffic{

    @Override
    public void go() {
        System.out.println("Drive : Car");
    }
}
