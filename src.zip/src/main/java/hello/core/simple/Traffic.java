package hello.core.simple;

public interface Traffic {

    void go();
}
